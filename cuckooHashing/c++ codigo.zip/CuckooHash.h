#pragma once
#include <iostream>
#include <vector>
#include <cstdint> // uint32_t, UINT32_MAX

using namespace std;

struct Entrada {
    uint32_t dni; // clave
    uint32_t idx; // posicion de la persona en la cache
};

const uint32_t VACIO = UINT32_MAX; // casilla vacia

class CuckooHash {
    uint32_t capacidad; // casillas de cada tabla
    vector<Entrada> tabla1;
    vector<Entrada> tabla2;

public:
    CuckooHash(size_t n) {
        capacidad = n / 0.9 + 1;
        tabla1.assign(capacidad, Entrada{0, VACIO});
        tabla2.assign(capacidad, Entrada{0, VACIO});
    }

    // metodo multiplicativo de Knuth
    uint32_t hash1(uint32_t dni) const {
        return (dni * 2654435769u) % capacidad;
    }

    // mezcla de Murmur
    uint32_t hash2(uint32_t dni) const {
        uint32_t x = dni;
        x ^= x >> 16;
        x *= 0x85ebca6bu;
        x ^= x >> 13;
        x *= 0xc2b2ae35u;
        x ^= x >> 16;
        return x % capacidad;
    }
};

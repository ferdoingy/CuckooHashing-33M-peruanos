#include <iostream>
#include <stdexcept> // exception
#include "Cache.h"
#include "CuckooHash.h"

using namespace std;

int main() {
    try {
        Cache cache;
        cache.cargar("../setDatosBIN/setDatos/dataset.bin");
        cout << "Personas en la cache: " << cache.size() << "\n";

        CuckooHash tabla(cache.size());
        cout << "Tablas creadas\n";
    } catch (const exception& e) {
        cerr << "Error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}

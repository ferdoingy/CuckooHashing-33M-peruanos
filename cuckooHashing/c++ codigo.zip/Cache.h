#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdint>
#include <stdexcept> // runtime_error

using namespace std;

// cabecera (176 bytes): "DNIP" | version | total | inicio[10] | cantidad[10]
// persona: 26 bytes fijos (el ultimo es el largo del correo) + usuario del correo
class Cache {
    vector<uint64_t> posiciones; // posiciones[i] = byte donde empieza la persona i

public:
    void cargar(const string& ruta) {
        ifstream archivo(ruta, ios::binary);
        if (!archivo) throw runtime_error("No se pudo abrir " + ruta);

        char magic[4];
        uint32_t version;
        uint64_t total;
        archivo.read(magic, 4);
        archivo.read((char*)&version, 4);
        archivo.read((char*)&total, 8);
        archivo.ignore(160); // inicio[10] y cantidad[10], no se usan

        if (string(magic, 4) != "DNIP") throw runtime_error("No es un archivo DNIP");
        if (version != 2) throw runtime_error("Se esperaba la version 2");

        posiciones.reserve(total);
        uint64_t pos = 176; // la primera persona va despues de la cabecera
        char registro[26];
        for (uint64_t i = 0; i < total; i++) {
            archivo.read(registro, 26);
            uint8_t largoCorreo = registro[25];
            archivo.ignore(largoCorreo); // se salta el correo

            posiciones.push_back(pos);
            pos += 26 + largoCorreo;
        }
    }

    size_t size() const { return posiciones.size(); }
};
